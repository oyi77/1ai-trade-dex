# PolyEdge Research Paper

## Overview

This directory contains the source files for the research paper:
**"PolyEdge: Autonomous Prediction Market Trading with Bounded AGI Safety, Evolutionary Strategy Composition, and Adversarial Decision Validation"**

## Files

| File | Description |
|------|-------------|
| `paper.tex` | Main LaTeX source file (assembles all sections) |
| `paper.bib` | BibTeX bibliography (18 verified references) |
| `paper.pdf` | Compiled PDF (32 pages) |
| `sections/sec3_architecture.tex` | System Architecture (Section 3) |
| `sections/sec4_autonomy.tex` | AGI Autonomy with Hard Safety Boundaries (Section 4) |
| `sections/sec5_evolution.tex` | Evolutionary Strategy Composition (Section 5) |
| `sections/sec6_debate.tex` | Dual-Debate Decision Validation (Section 6) |
| `sections/sec7_results.tex` | Experiments & Results (Section 7) |
| `sections/sec8_discussion.tex` | Discussion & Future Work (Section 8) |
| `sections/sec9_manifesto.tex` | Manifesto (Appendix) |
| `figures/architecture.pdf` | System architecture diagram |
| `figures/autonomy_pipeline.pdf` | ADR-006 experiment lifecycle pipeline |
| `figures/genome.pdf` | StrategyGenome chromosome structure |
| `figures/debate_flow.pdf` | MiroFish dual-debate flow |
| `figures/performance.pdf` | Performance chart placeholder |
| `figures/experiments.pdf` | Experiment lifecycle heatmap placeholder |
| `data/metrics.csv` | Extracted dashboard metrics |
| `data/experiments.json` | Experiment summary from SQLite DB |
| `data/system_stats.json` | Codebase scale metrics |
| `manifesto.md` | Standalone manifesto document |

## Compiling

```bash
cd docs/paper
pdflatex paper.tex
bibtex paper
pdflatex paper.tex
pdflatex paper.tex
```

Or with `latexmk`:
```bash
latexmk -pdf paper.tex
```

## Dependencies

- `pdflatex` (TeX Live or MiKTeX)
- Standard packages: `amsmath`, `graphicx`, `hyperref`, `natbib`, `booktabs`, `tikz`

## arXiv Submission

1. Replace placeholder figures (`figures/performance.pdf`, `figures/experiments.pdf`) with publication-quality charts generated from `data/metrics.csv`.
2. Add arXiv metadata in `paper.tex` comments or upload separately.
3. Categories: `cs.AI`, `q-fin.TR`, `cs.LG`
4. Upload source files as a single `.tar.gz`.

## Zenodo Artifact

See `supplementary.zip` for the complete artifact including:
- All source code (from project root, excluding `.env`)
- Data files (`data/*.csv`, `data/*.json`)
- Extra figures and raw TikZ sources
- This README

## Data Provenance

All metrics and experiment data were extracted from the live PolyEdge deployment at `polyedge.aitradepulse.com` and the SQLite database `data/polyedge.db`. No data was fabricated.

## License

MIT - same as the PolyEdge project.
